let state = {
    timuList:[],
}


export default state 