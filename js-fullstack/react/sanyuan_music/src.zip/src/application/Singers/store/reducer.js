const defaultState = {
  category: "",
  alpha: "",
  singleList: [],
  enterLoading: true,
  listOffset: 0
}

export default (state = defaultState, action) = {
  switch(action.type){
  default:
  return state
}
}